## CLA

In order to contribute to tota11y, you must first sign the CLA, which can be found at http://www.khanacademy.org/r/cla.

## License

tota11y is licensed under the [MIT License](http://opensource.org/licenses/MIT).
